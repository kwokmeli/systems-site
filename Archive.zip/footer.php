</div><!-- /.container -->
<footer class="blog-footer">
  <a href="mailto:syshelp@hsl.washington.edu">Contact Us</a><br>
  Copyright © 2018 <a href="https://hsl.uw.edu/">University of Washington Health Sciences Library</a>
</footer>

<?php wp_footer(); ?>
</body>
</html>
