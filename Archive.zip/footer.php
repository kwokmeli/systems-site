</div><!-- /.container -->
<footer class="blog-footer">

  <!-- <a href="https://www.facebook.com/uwhsl"><img src="<?php bloginfo('template_directory'); ?>/img/facebook.png"/></a>
  <a href="https://twitter.com/uwhsl"><img src="<?php bloginfo('template_directory'); ?>/img/twitter.png"/></a> -->

  <div class="footer-link"><a href="/sitemap/">Sitemap</a></div>
  <div class="footer-link"><a href="mailto:syshelp@hsl.washington.edu">Contact</a></div>
  <div class="footer-link"><a href="">About</a></div>

  <div class="footer-divider"></div>


  <div class="footer-link">© 2018 <a href="https://hsl.uw.edu/">University of Washington Health Sciences Library</a></div>

</footer>

<?php wp_footer(); ?>
</body>
</html>
