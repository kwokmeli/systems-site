<form role="search" method="get" id="searchform" class="searchform" action="<?php echo home_url( '/' ); ?>">
    <div>
        <input type="text" value="" name="s" id="s" placeholder="Search..." />
        <div class="search-button"><input type="image" src="<?php bloginfo('template_directory'); ?>/img/mag-blue.png" id="searchsubmit" /></div>
    </div>
</form>
